package org.vaadin.training.calendarpicker.client.calendarpicker;

import com.vaadin.shared.communication.ServerRpc;

public interface CaledanrPickerServerRpc extends ServerRpc {

    // TODO example API
    public void setDate(long newValue);

}
