package org.vaadin.training.views.dashboard;

public interface DashboardView {

}
