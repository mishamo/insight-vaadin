package org.vaadin.training.stepper.client.stepper;

public class StepperState extends com.vaadin.shared.AbstractFieldState {

    public Integer value;

}
