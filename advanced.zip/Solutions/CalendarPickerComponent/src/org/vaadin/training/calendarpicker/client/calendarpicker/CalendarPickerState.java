package org.vaadin.training.calendarpicker.client.calendarpicker;

import java.util.Date;

public class CalendarPickerState extends com.vaadin.shared.AbstractComponentState {

    public long date = new Date().getTime();

}
