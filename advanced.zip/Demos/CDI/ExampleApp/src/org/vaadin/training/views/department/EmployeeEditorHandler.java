package org.vaadin.training.views.department;

public interface EmployeeEditorHandler {

	public void onSaveClick();

	public void onCancelClick();

}
