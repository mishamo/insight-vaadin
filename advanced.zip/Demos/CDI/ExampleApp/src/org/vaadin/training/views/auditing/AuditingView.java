package org.vaadin.training.views.auditing;

public interface AuditingView {

	public void addAuditLog(String message);

}
